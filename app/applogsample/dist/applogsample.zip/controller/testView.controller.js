sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("applogsample.controller.testView",{onInit:function(){}})});
//# sourceMappingURL=testView.controller.js.map